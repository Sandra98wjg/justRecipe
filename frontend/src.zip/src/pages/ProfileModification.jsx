import ProfileModificationForm from '../components/ProfileModificationForm';
import { ApiCall } from '../components/ApiCall';
import { useNavigate } from 'react-router-dom';

// import { ApiCall } from '../components/ApiCall';

function ProfileModificaton() {
    const navigate = useNavigate();

    return <>
        <ProfileModificationForm submit={async (username,email, password) => {
            const body = {
                "username": username?username:null,
                "email": email?email:null,
                "password": password?password:null,
                "id":localStorage.getItem("userId")
            };
            ApiCall('PUT', `user/userUpdate/${localStorage.getItem("userId")}`, body).then((data) => {
                // localStorage.setItem('token', data.token);
                // console.log('token' + data.token);
                console.log(data)
                navigate('/home');
            }).catch(alert);

        }} />
    </>;
}

export default ProfileModificaton;