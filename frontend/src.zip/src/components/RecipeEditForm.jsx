import React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import Input from '@mui/material/Input';
import Modal from '@mui/material/Modal';
import Stack from '@mui/material/Stack';
import { ApiCall } from '../components/ApiCall';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function fileToDataUrl(file) {
    const validFileTypes = [ 'image/jpeg', 'image/png', 'image/jpg' ]
    const valid = validFileTypes.find(type => type === file.type);
    // Bad data, let's walk away.
    if (!valid) {
        throw Error('provided file is not a png, jpg or jpeg image.');
    }

    const reader = new FileReader();
    const dataUrlPromise = new Promise((resolve,reject) => {
        reader.onerror = reject;
        reader.onload = () => resolve(reader.result);
    });
    reader.readAsDataURL(file);
    return dataUrlPromise;
}

const deleteModalStyle = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};

function RecipeEditForm({ submit, rid }) {
    const navigate = useNavigate();
    const [recipeName, setRecipeName] = useState('')
    const [ingredients, setIngredients] = useState([])
    const [methods, setMethods] = useState([])
    const [image, setImage] = useState('')
    const [deleteModalOpen, setDeleteModalOpen] = useState(false);

    function getRecipeInfo(){
      ApiCall('GET',`recipe/getRecipe/${rid}/${localStorage.getItem("userId")}`)
      .then(data=>{
        console.log(data)
        setRecipeName(data.name)
        setImage(data.imgUrl)
        setMethods([{method: 'Chop ingredients', id: '0'}, {method: 'Cook Ingredients', id: '1'}, {method: 'Eat Food', id: '2'}])
        setIngredients([{ingredient: 'Spaghetti', id: '0'}, {ingredient: 'Mince Meat', id: '1'}, {ingredient: 'Ragu', id: '2'}])

      })
      // setName('Spaghetti Alla Bolognese');
      // setImg('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVQYV2NgYAAAAAMAAWgmWQ0AAAAASUVORK5CYII=');

    }

    const addIngredient = () => {
        const temp = [...ingredients];
        temp.push({ id: temp.length.toString(), ingredient: 'Ingredient' })
        setIngredients(temp);
    }

    const addMethod = () => {
        const temp = [...methods];
        temp.push({ id: temp.length.toString(), method: 'Step' })
        setMethods(temp);
    }

    const onSubmit = (e) => {
        e.preventDefault();
        let stringIngredients = ""
        for (let i = 0; i < ingredients.length; i++) {
            stringIngredients += ingredients[i].ingredient
            stringIngredients += ","
        }
        let stringMethods = ""
        for (let i = 0; i < methods.length; i++) {
            stringMethods += methods[i].method
            stringMethods += ","
        }
        if (!image) {
            console.log('submitted')
            // set to default picture here
            
            submit(recipeName, stringIngredients, stringMethods, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVQYV2NgYAAAAAMAAWgmWQ0AAAAASUVORK5CYII=');
        } else {
            image.then(data => {
                submit(recipeName, stringIngredients, stringMethods, data);
                console.log('submitted')
            });
        }
    }

    const setIngredient = (e) => {
        const temp = [...ingredients];
        temp.push({ id: temp.length.toString(), ingredient: 'Ingredient' })
        setIngredients(temp);
    }

    const removeIngredient = (id) => {
        const temp = [...ingredients];
        temp.splice(id, 1);
        for (let i=0; i<temp.length; i++) {
            temp[i].id = i.toString()
        }
        setIngredients(temp);
    }

    const removeMethod = (id) => {
        const temp = [...methods];
        temp.splice(id, 1);
        for (let i=0; i<temp.length; i++) {
            temp[i].id = i.toString()
        }
        setMethods(temp);
    }

    const openDeleteModal = () => {
        setDeleteModalOpen(true)
    }

    const deleteRecipe = () => {
        console.log('deleting')
        // TODO
        navigate('/home/')
    }
    useEffect(()=>{
      getRecipeInfo()
    },[])

    useEffect(() =>{
      console.log(recipeName)
    }, [recipeName])
    if (recipeName != '') {
      return (<>
          <Container component="main" maxWidth="md">
              <Grid container spacing={5} pt={10} pb={50}>
                  <Grid item md={12}>
                      <Button sx={{borderRadius: 3,
                                   color: '#888888',
                                   backgroundColor: '#ffffff',
                                   fontSize: 18,
                                   height: 250,
                                   '&:hover': {
                                      color: '#666666',
                                      backgroundColor: '#dddddd',
                                    }}}
                              variant="contained"
                              component="label"
                              fullWidth>
                          Upload Image
                          <input type="file" hidden onChange={e => { setImage(fileToDataUrl(e.target.files[0])); console.log(image)}}/>
                      </Button>
                  </Grid>
                  <Grid item md={12}>
                      <Typography pb={3} variant="h5">Recipe Name</Typography>
                      <TextField id="recipe-name"
                                  className="inputForm"
                                  fullWidth
                                  label="Recipe Name"
                                  defaultValue={recipeName}
                                  variant="outlined"
                                  onChange={(e) => setRecipeName(e.target.value)}>
                      </TextField>
                  </Grid>
                  <Grid item md={12}>
                      <Typography pb={3} variant="h5">Ingredients</Typography>
                      <Grid container spacing={3}>
                          {ingredients.map((ingredient, index) => <Grid item key={ingredient.id} md={12}>
                              <TextField
                                  key={ingredient.id}
                                  id={ingredient.id}
                                  className="inputForm"
                                  fullWidth
                                  label='Ingredient'
                                  defaultValue={ingredient.ingredient}
                                  variant="outlined"
                                  pb={3}
                                  onChange={(e) => {
                                      ingredient.ingredient = e.target.value
                                  }}
                              />
                              <Button variant='contained'
                                      color='error'
                                      onClick={(e) => {
                                          removeIngredient(ingredient.id)
                                      }}
                                      >
                                  Delete
                              </Button>
                          </Grid>
                          )}
                          <Grid item md={12}>
                              <Button sx={{borderRadius: 3}} mt={2} variant="contained" fullWidth onClick={() => {
                                  addIngredient();
                              }}>
                                  Add Ingredient
                              </Button>
                          </Grid>
                      </Grid>
                  </Grid>

                  <Grid item md={12}>
                      <Typography pb={3} variant="h5">Methods</Typography>
                      <Grid container spacing={3}>
                          {methods.map((method, index) => <Grid item key={method.id} md={12}>
                              <TextField
                                  key={method.id}
                                  id={method.id}
                                  className="inputForm"
                                  fullWidth
                                  label="Method"
                                  defaultValue={method.method}
                                  variant="outlined"
                                  pb={3}
                                  onChange={(e) => {
                                      method.method = e.target.value
                                  }}
                              />
                              <Button variant='contained'
                                      color='error'
                                      onClick={(e) => {
                                          removeMethod(method.id)
                                      }}
                                      >
                                  Delete
                              </Button>
                          </Grid>
                          )}
                          <Grid item md={12}>
                              <Button sx={{borderRadius: 3}} mt={2} variant="contained" fullWidth onClick={() => {
                                  addMethod();
                              }}>
                                  Add Step
                              </Button>
                          </Grid>
                      </Grid>
                  </Grid>
                  <Grid item md={12}>
                      <Button sx={{borderRadius: 3}}
                              variant="contained"
                              fullWidth
                              style={{ height: 70 }}
                              onClick={onSubmit}>
                          Submit
                      </Button>
                  </Grid>
                  <Grid item md={12}>
                      <Button sx={{borderRadius: 3}}
                              variant="contained"
                              color="error"
                              fullWidth
                              style={{ height: 70 }}
                              onClick={openDeleteModal}>
                          Delete Recipe
                      </Button>
                  </Grid>
                  <Modal
                      open={deleteModalOpen}
                      onClose={() => setDeleteModalOpen(false)}
                  >
                      <Box sx={deleteModalStyle}>
                          <Stack spacing={2}>
                              <Typography>Are you sure you want to delete this recipe?</Typography>
                              <Button variant="contained" onClick={deleteRecipe} color="error">Yes, delete it</Button>
                              <Button variant="contained" onClick={() => setDeleteModalOpen(false)} color="primary">No, take me back</Button>
                          </Stack>
                      </Box>

                  </Modal>
              </Grid>
          </Container>
      </>)
    } else {
        return(<>Loading</>)
    }
}

    export default RecipeEditForm;
