import React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import Input from '@mui/material/Input';
import PublishForm from '../components/PublishForm';
import { useNavigate } from 'react-router-dom';
import { ApiCall } from '../components/ApiCall';


function Publish() {
    const navigate = useNavigate();
    return (<>
        <PublishForm submit={async (recipeName, ingredients, methods, image) => {
            let body = {'name': recipeName, 'ingredient': ingredients, 'mealType': 'temp', 'method': methods, 'imgUrl': image };
            console.log(body, )
            ApiCall('POST', `recipe/createRecipe/${localStorage.getItem("userId")}`, body).then((data) => {
                navigate('/home/');
            }).catch(alert);

        }} />
    </>)
    }

    export default Publish;
