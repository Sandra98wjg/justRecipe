import React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import Input from '@mui/material/Input';
import { useNavigate } from 'react-router-dom';
import { ApiCall } from '../components/ApiCall';
import { useParams } from 'react-router-dom';
import RecipeEditForm from '../components/RecipeEditForm';



function RecipeEdit() {
    const navigate = useNavigate();
    const params=useParams()
    return (<>
        <RecipeEditForm rid={params.rid} submit={async (recipeName, ingredients, methods, image) => {
            let body = {
                "imgUrl": image,
                "ingredient": ingredients,
                "mealType": "string",
                "method": methods,
                "name": recipeName
        };
        console.log(ingredients.ingredients)
            console.log(body)
            ApiCall('PUT', `updateRecipe/${params.rid}`, body).then((data) => {
                navigate('/home/');
            }).catch(alert);
            // window.location.href = `/recipes/${params.rid}`

        }} />
    </>)
    }

    export default RecipeEdit;
