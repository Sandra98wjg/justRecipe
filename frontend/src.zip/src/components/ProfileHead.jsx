import React from "react";
import BorderColorIcon from '@material-ui/icons/BorderColor';
import { Link } from 'react-router-dom';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import { display } from "@mui/system";

function ProfileHead(props) {

    return<>
        <div className='user-information'>
            <Avatar sx={{ width: 60, height: 60 }}>U</Avatar>
            <div className='name-email'>
                <h1>{props.name}</h1>
                <div className='email-modify'>
                    <div>{props.email}</div>
                    <div style={props.showEdit ? {display: 'block'} : {display: 'none'}}>
                        <Link to="/profile/modification" className='profile-modify'>
                        <Button color="primary">
                            <BorderColorIcon/>
                            Modify my information
                        </Button>
                        </Link>
                    </div>
                    <div style={!props.showEdit ? {display: 'block'} : {display: 'none'}}>
                        <Button onClick={()=> {console.log('subscribing')}} color="primary">
                            <BorderColorIcon/>
                            Subscribe to this User
                        </Button>
                    </div>
                    <div className='profile-modify' style={{ display: 'none' }}>
                        <Button variant="outlined" href="#outlined-buttons" size="large" sx={{ display: "inline" }}>
                            Followed
                        </Button>
                    </div>
                </div>
            </div>
        </div>
        <hr/>
        <div className='user-profile-btn'>
            <Button onClick={(e)=> {
                e.preventDefault()
                window.location.href = `/profile/${props.id}`
            }}><Link className='profile-recipe-word'>{props.name}'s recipes</Link></Button>
            <Button onClick={(e)=> {
                e.preventDefault()
                window.location.href = `/profile/follower/${props.id}`
            }}
            ><Link className='profile-recipe-word'>{props.name}'s follows</Link></Button>
        </div>
    </>
}
export default ProfileHead;
