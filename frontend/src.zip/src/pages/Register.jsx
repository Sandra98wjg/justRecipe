import RegisterForm from '../components/RegisterForm';
import Alert from '@mui/material/Alert';
import { useNavigate } from 'react-router-dom';
import { ApiCall } from '../components/ApiCall';


function Register() {
    const navigate = useNavigate();

    return <>
        <RegisterForm submit={async (username, email, password) => {
            const body = {
                "email": email,
                "username": username,
                "password": password,
            };
            ApiCall('PUT', 'user/userRegister', body).then((data) => {
                // localStorage.setItem('token', data.token);
                // console.log('token: ' + data.token);
                localStorage.setItem('userId',data.uid)
                navigate('/home/');
            }).catch(alert);

        }} />
    </>;
}

export default Register;
