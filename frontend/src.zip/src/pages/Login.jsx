import LoginForm from '../components/LoginForm';
import Alert from '@mui/material/Alert';
import Container from '@mui/material/Container';
import Collapse from '@mui/material/Collapse';
import { useNavigate } from 'react-router-dom';
import { ApiCall } from '../components/ApiCall';
import React from 'react';

function Login() {
    const navigate = useNavigate();
    const [showErrBlock, setShowErrBlock] = React.useState(false);
    const handleBadLogin = (errCode) => {
        console.log(errCode)
        if (errCode === 400) {
            setShowErrBlock(true)
            console.log('handled')
        }
    }
    return <>
        <LoginForm submit={async (username, password) => {
            const body = {
                // "email": "string",
                "username": username,
                "password": password,
            };
            ApiCall('POST', 'user/userLogin', body, handleBadLogin).then((data) => {
                if (data) {
                    localStorage.setItem('userId',data.uid)

                    // localStorage.setItem('token', data.token);
                    // console.log('token: ' + data.token);
                    navigate('/home/');
                } else {
                    setShowErrBlock(true)
                }
            }).catch(alert);

        }} />
        <Container component="main" maxWidth="xs">
            <Collapse in={showErrBlock}>
                <Alert severity="error">Incorrect username or password!</Alert>
            </Collapse>
        </Container>
    </>;
}

export default Login;
