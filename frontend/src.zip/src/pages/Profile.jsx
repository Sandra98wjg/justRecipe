import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';
import PrimarySearchAppBar from '../components/NavigationBar';
import RecipeCard from '../components/RecipeCard';
import '../assets/css/Profile.css'
import ProfileHead from '../components/ProfileHead';
import { useEffect, useState } from 'react';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import { ApiCall } from '../components/ApiCall';
import RecipePagination from '../components/RecipePagination';


function Profile() {
  const navigate = useNavigate()
  const [id,setId] = useState('')
  const [name, setName] = useState('')
  const [email,setEmail] = useState('')
  const [recipes, setRecipes] = useState([])
  const [page, setPage] = useState(1)
  const [recipeNum, setRecipeNum] = useState(0)
  const [showEdit, setShowEdit] = useState(false)
  const recipesPerPage = 20
  const params=useParams()

  // get all user info
  function getUserInfo(){
    if (localStorage.getItem("userId") === null) {
        navigate('/login/');
    } else {
        ApiCall('GET',`user/getProfile/${params.uid}`)
          .then(data => {
          setName(data.name)
          setEmail(data.email)
            setRecipes(data.recipes)
            setId(params.uid)
          console.log("srn type", typeof setRecipeNum)
          setRecipeNum(data.recipes.length)
          params.uid === localStorage.getItem("userId") ? setShowEdit(true) : setShowEdit(false)
        })
    }
  }

  useEffect(()=>{
    getUserInfo()
  },[])

  function toRecipeDetail(id){
    navigate(`/recipe/${id}`)
  }

  const RecipeTotal=()=>{
    const recipeInfo = recipes.slice((page - 1) * recipesPerPage,page * recipesPerPage)
      .map(recipe => {
      return(
        <>
        <Grid item xs={3}>
        <RecipeCard
          key={recipe.id}
          id={recipe.id}
          title={recipe.title}
          img={recipe.img}
          name={name}
        />
        </Grid>
        </>
      )
    })
    return(
      <Paper
      sx={{
      p: 2,
      margin: 'auto',
      maxWidth: "80%",
      flexGrow: 1,
      backgroundColor:'#f5f5dc',
      border:'none'
    }}
  >
    <Grid container spacing={2}>
        {recipeInfo}
      </Grid>
  </Paper>
      )
  }

  return <>
      <PrimarySearchAppBar/>
    <ProfileHead
      id={id}
      name={name}
      email={email}
      showEdit={showEdit}
      />
    <RecipeTotal />
    <RecipePagination
          setPage={setPage}
          page={page}
          totalPage={Math.ceil(recipeNum/recipesPerPage)}
      />
  </>;
}

export default Profile;
