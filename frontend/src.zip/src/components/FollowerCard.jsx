import * as React from "react";
import ListItem from "@mui/material/ListItem";
import Divider from "@mui/material/Divider";
import ListItemText from "@mui/material/ListItemText";
import Avatar from "@mui/material/Avatar";
import Typography from "@mui/material/Typography";
import Button from '@mui/material/Button';
import { useState,useEffect } from "react";

export default function FollowerCard(props) {
  let [follow, setFollow] = useState(true);
  const followChange=(e)=> {
    setFollow(!follow)
    e.preventDefault()
  }
  
  return(<>
    <ListItem alignItems="flex-start">
    <Avatar sx={{ width: 60, height: 60 }}>U</Avatar>
    <ListItemText
      primary={props.name}
      secondary={
        <React.Fragment>
          <Typography
            sx={{ display: "inline" }}
            component="span"
            variant="body2"
            color="text.primary"
          >
            {props.email}
            <div className='unfollow-btn' style={follow ? { display: 'block' } : { display: 'none' }}>
              <Button variant="outlined" href="#outlined-buttons" size="small" sx={{ display: "inline" }} onClick={followChange}>
                Followed
              </Button>
            </div>
            <div className='unfollow-btn' style={follow ? { display: 'none' } : { display: 'block' }}>
              <Button variant="outlined" href="#outlined-buttons" size="small" color="info" sx={{ display: "inline" }} onClick={followChange}>
                Follow
              </Button>
            </div>
          </Typography>
        </React.Fragment>
      }
    />
    </ListItem>
  <Divider variant="inset" component="li" />
  </>
)}
        
        