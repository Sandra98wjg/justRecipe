import React from 'react';
import { useNavigate } from 'react-router-dom';
import PrimarySearchAppBar from '../components/NavigationBar';
import RecipeCard from '../components/RecipeCard';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import '../assets/css/Home.css'
import { Link } from 'react-router-dom';
import Button from '@mui/material/Button';

function Home() {
  const navigate = useNavigate();
  

  const WhatsHot=()=>{
      const recipeInfo=Array.from(Array(4)).map( (recipe, index)=>{
        return(
          <Grid item xs={3} key={index}>
            <RecipeCard key={index}/>
          </Grid>
        )
      })
      return(
    <Paper
        sx={{
        p: 2,
        margin: 'auto',
        maxWidth: "80%",
        flexGrow: 1,
        backgroundColor:'#f5f5dc',
        border:'none'
      }}
    >
      <Grid container spacing={2}>
          {recipeInfo}
        </Grid>
    </Paper>
        )
    }

    const NewsFeed=()=>{
      const recipeInfo=Array.from(Array(4)).map( (recipe,index) =>{
        return(
          <Grid item xs={3} key={index}>
            <RecipeCard key={index}/>
          </Grid>
        )
      })
      return(
        <Paper
        sx={{
        p: 2,
        margin: 'auto',
        maxWidth: "80%",
        flexGrow: 1,
        backgroundColor:'#f5f5dc',
        border:'none'
      }}
    >
      <Grid container spacing={2}>
          {recipeInfo}
        </Grid>
    </Paper>
        )
  }
  function toRandom() {
    window.location.href = `/randomRecipe`
  }

  return (<>
    <PrimarySearchAppBar />
    <div className='random-btn'>
      <Button variant="contained" color="primary">
        Random Reacipe
      </Button>
    </div>
    
  <div className='whats-hot'>
    <h1 className='whats-hot-title'>What's hot today</h1>
    <WhatsHot />
    <div>
      <Link to="/whatsHot" className='more-on-home'>
        <Button color="primary">
            More &gt;
        </Button>
      </Link>  
    </div>
    </div>
    {/* style={{ display: 'none' }} */}
    <div className='whats-hot'>
    <h1 className='whats-hot-title'>Your news feed</h1>
    <NewsFeed />
    <div>
      <Link to="/newsFeed" className='more-on-home news-feed'>
        <Button color="primary" >
            More &gt;
        </Button>
      </Link>  
    </div> 
  </div>
  </>);
}

export default Home;
